package com.example.farsiconverter

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val keyMap = mapOf(
        'q' to 'ض', 'w' to 'ص', 'e' to 'ث', 'r' to 'ق', 't' to 'ف', 'y' to 'غ', 'u' to 'ع', 'i' to 'ه', 'o' to 'خ', 'p' to 'ح', '[' to 'ج', ']' to 'چ',
        'a' to 'ش', 's' to 'س', 'd' to 'ی', 'f' to 'ب', 'g' to 'ل', 'h' to 'ا', 'j' to 'ت', 'k' to 'ن', 'l' to 'م', ';' to 'ک', '\'' to 'گ',
        'z' to 'ظ', 'x' to 'ط', 'c' to 'ز', 'v' to 'ر', 'b' to 'ذ', 'n' to 'د', 'm' to 'ئ', ',' to 'و', '.' to '.', '/' to '؟', '`' to 'پ'
    )
    private lateinit var input: EditText
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,17,20)
        window.navigationBarColor = Color.rgb(16,17,20)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 20); setBackgroundColor(Color.rgb(16,17,20)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = ViewGroup.LayoutParams(-1, -2) }
        val title = TextView(this).apply { text = "تبدیل‌گر حروف"; textSize = 26f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 12, 0, 8) }
        val subtitle = TextView(this).apply { text = "حروف انگلیسی را با چیدمان استاندارد فارسی تبدیل کن"; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 24) }
        input = EditText(this).apply { hint = "اینجا انگلیسی تایپ کن…"; textSize = 20f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine(false); minLines = 3; gravity = Gravity.TOP or Gravity.START; setPadding(14,14,14,14); setBackgroundColor(Color.rgb(35,37,42)) }
        output = TextView(this).apply { text = "نتیجه اینجا نمایش داده می‌شود"; textSize = 24f; setTextColor(Color.rgb(128,203,196)); gravity = Gravity.RIGHT; setPadding(14,20,14,20); minHeight = 100; setBackgroundColor(Color.rgb(35,37,42)) }
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { output.text = convert(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        val copy = Button(this).apply { text = "کپی نتیجه"; setOnClickListener { val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; cb.setPrimaryClip(ClipData.newPlainText("نتیجه", output.text)); text = "کپی شد ✓" } }
        val clear = Button(this).apply { text = "پاک کردن"; setOnClickListener { input.text.clear(); output.text = "نتیجه اینجا نمایش داده می‌شود" } }
        val note = TextView(this).apply { text = "توجه: این برنامه ترجمه نمی‌کند؛ فقط هر کلید انگلیسی را طبق جایگاه چیدمان فارسی تبدیل می‌کند."; textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0,18,0,8) }
        content.addView(title); content.addView(subtitle); content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 16 }); content.addView(output, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        content.addView(copy); content.addView(clear); content.addView(note)
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }
    private fun convert(text: String): String = text.map { ch ->
        val mapped = keyMap[ch.lowercaseChar()]
        if (mapped != null) mapped.toString() else ch.toString()
    }.joinToString("")
}
